import 'package:permission_handler/permission_handler.dart';

/// Bluetooth/Nearby group chat ke liye zaroori sab runtime permissions
/// ek saath maang leta hai. Android 12+ par Bluetooth ke liye alag hi
/// permissions chahiye (BLUETOOTH_SCAN, BLUETOOTH_ADVERTISE, BLUETOOTH_CONNECT).
class PermissionHelper {
  static Future<bool> requestAll() async {
    final statuses = await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.location, // Bluetooth scan ke liye Android par zaroori
      Permission.nearbyWifiDevices,
    ].request();

    return statuses.values.every(
      (status) => status.isGranted || status.isLimited,
    );
  }
}
