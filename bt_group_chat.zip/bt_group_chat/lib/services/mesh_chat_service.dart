import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:nearby_connections/nearby_connections.dart';
import 'package:uuid/uuid.dart';

import '../models/chat_message.dart';

/// Yeh service poore app ka "network layer" hai.
///
/// Kaam kaise karta hai:
/// - Har device EK SAATH advertiser (dusre devices ko dikhna) aur
///   discoverer (dusre devices ko dhoondhna) dono ban jaata hai.
/// - `Strategy.P2P_CLUSTER` use karte hain — isse many-to-many (group)
///   connections banti hain, sirf 1-to-1 nahi.
/// - Jab bhi koi message aata hai, use sirf apne UI me dikhate nahin —
///   balki baaki sab connected devices ko bhi FORWARD (relay) kar dete
///   hain. Isse agar A aur C seedhe range me na hon lekin B dono ke
///   range me ho, to B ke through A ka message C tak pahunch jaata hai
///   (chhota sa "mesh" effect, group chat ke liye zaroori).
/// - Har message ki ek unique `id` hoti hai, jisse ek hi message baar
///   baar loop hoke forward na ho (duplicate check).
class MeshChatService {
  MeshChatService({required this.userName}) : deviceId = const Uuid().v4();

  final String userName;
  final String deviceId; // is device ki unique pehchaan is session ke liye

  final Nearby _nearby = Nearby();
  final String _serviceId = 'com.example.bt_group_chat';

  // Connected peers: endpointId -> displayName
  final Map<String, String> connectedPeers = {};

  // Duplicate messages ko rokne ke liye recently-seen message IDs
  final Set<String> _seenMessageIds = {};

  final StreamController<ChatMessage> _messageController =
      StreamController<ChatMessage>.broadcast();
  final StreamController<Map<String, String>> _peersController =
      StreamController<Map<String, String>>.broadcast();

  /// Naye messages (khud ke bheje hue + doosron se mile hue) yahan se milte hain.
  Stream<ChatMessage> get messages => _messageController.stream;

  /// Connected peers ki list jab bhi badle, yahan se update milta hai.
  Stream<Map<String, String>> get peersUpdates => _peersController.stream;

  bool _isRunning = false;

  /// Advertising + Discovery dono shuru karo — device ab "visible" bhi hai
  /// aur dusre devices ko "dhoond" bhi raha hai.
  Future<void> start() async {
    if (_isRunning) return;
    _isRunning = true;

    await _nearby.startAdvertising(
      userName,
      Strategy.P2P_CLUSTER,
      onConnectionInitiated: _onConnectionInitiated,
      onConnectionResult: _onConnectionResult,
      onDisconnected: _onDisconnected,
      serviceId: _serviceId,
    );

    await _nearby.startDiscovery(
      userName,
      Strategy.P2P_CLUSTER,
      onEndpointFound: (endpointId, endpointName, serviceId) {
        // Jaise hi koi naya device mile, turant connect karne ki request bhejo
        _nearby.requestConnection(
          userName,
          endpointId,
          onConnectionInitiated: _onConnectionInitiated,
          onConnectionResult: _onConnectionResult,
          onDisconnected: _onDisconnected,
        );
      },
      onEndpointLost: (endpointId) {
        // range se bahar chala gaya
      },
      serviceId: _serviceId,
    );
  }

  Future<void> stop() async {
    _isRunning = false;
    connectedPeers.clear();
    await _nearby.stopAdvertising();
    await _nearby.stopDiscovery();
    await _nearby.stopAllEndpoints();
  }

  void _onConnectionInitiated(String endpointId, ConnectionInfo info) {
    // Auto-accept — group chat me manual approval ki zaroorat nahi.
    _nearby.acceptConnection(
      endpointId,
      onPayLoadRecieved: (endpointId, payload) {
        if (payload.type == PayloadType.BYTES && payload.bytes != null) {
          final jsonStr = utf8.decode(payload.bytes!);
          _handleIncomingRaw(jsonStr, fromEndpoint: endpointId);
        }
      },
    );
  }

  void _onConnectionResult(String endpointId, Status status) {
    if (status == Status.CONNECTED) {
      // Naam abhi discovery se pata nahi chalta connection callback me,
      // isliye placeholder rakhte hain — pehla message aane par update ho jaata hai.
      connectedPeers[endpointId] = connectedPeers[endpointId] ?? 'Peer';
      _peersController.add(Map.from(connectedPeers));

      _broadcastSystemMessage('$userName group me connect hua');
    }
  }

  void _onDisconnected(String endpointId) {
    final name = connectedPeers.remove(endpointId);
    _peersController.add(Map.from(connectedPeers));
    if (name != null) {
      _broadcastSystemMessage('$name disconnect ho gaya');
    }
  }

  void _handleIncomingRaw(String jsonStr, {required String fromEndpoint}) {
    try {
      final msg = ChatMessage.fromJson(jsonStr);

      // Duplicate? to ignore — isse relay-loop nahi banega
      if (_seenMessageIds.contains(msg.id)) return;
      _seenMessageIds.add(msg.id);

      // Sender ka naam yaad rakh lo taaki peer list me sahi dikhe
      if (!msg.isSystem) {
        connectedPeers[fromEndpoint] = msg.senderName;
        _peersController.add(Map.from(connectedPeers));
      }

      _messageController.add(msg);

      // MESH RELAY: yahi se message baaki sab connected devices tak
      // (jo already isse na pahunch chuke hon) forward ho jaata hai.
      _relayToOthers(jsonStr, exceptEndpoint: fromEndpoint);
    } catch (_) {
      // malformed payload, ignore
    }
  }

  void _relayToOthers(String jsonStr, {required String exceptEndpoint}) {
    final bytes = Uint8List.fromList(utf8.encode(jsonStr));
    for (final endpointId in connectedPeers.keys) {
      if (endpointId == exceptEndpoint) continue;
      _nearby.sendBytesPayload(endpointId, bytes);
    }
  }

  /// Apna naya message poore group ko bhejo.
  void sendMessage(String text) {
    final msg = ChatMessage(
      id: const Uuid().v4(),
      senderId: deviceId,
      senderName: userName,
      text: text,
      timestamp: DateTime.now().millisecondsSinceEpoch,
    );
    _seenMessageIds.add(msg.id);
    _messageController.add(msg); // apni screen par turant dikhao

    final bytes = Uint8List.fromList(utf8.encode(msg.toJson()));
    for (final endpointId in connectedPeers.keys) {
      _nearby.sendBytesPayload(endpointId, bytes);
    }
  }

  void _broadcastSystemMessage(String text) {
    final msg = ChatMessage(
      id: const Uuid().v4(),
      senderId: 'system',
      senderName: 'System',
      text: text,
      timestamp: DateTime.now().millisecondsSinceEpoch,
      isSystem: true,
    );
    _seenMessageIds.add(msg.id);
    _messageController.add(msg);
  }

  void dispose() {
    stop();
    _messageController.close();
    _peersController.close();
  }
}
