import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const BtGroupChatApp());
}

class BtGroupChatApp extends StatelessWidget {
  const BtGroupChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Offline Group Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
