import 'dart:convert';

/// Ek single chat message ko represent karta hai.
/// `id` har message ke liye unique hota hai — isi se mesh flooding me
/// duplicate messages ko discard kiya jaata hai.
class ChatMessage {
  final String id;
  final String senderId;
  final String senderName;
  final String text;
  final int timestamp; // milliseconds since epoch
  final bool isSystem; // "X joined" jaisे system messages ke liye

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.text,
    required this.timestamp,
    this.isSystem = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'senderId': senderId,
        'senderName': senderName,
        'text': text,
        'timestamp': timestamp,
        'isSystem': isSystem,
      };

  factory ChatMessage.fromMap(Map<String, dynamic> map) => ChatMessage(
        id: map['id'] as String,
        senderId: map['senderId'] as String,
        senderName: map['senderName'] as String,
        text: map['text'] as String,
        timestamp: map['timestamp'] as int,
        isSystem: map['isSystem'] as bool? ?? false,
      );

  String toJson() => jsonEncode(toMap());

  factory ChatMessage.fromJson(String source) =>
      ChatMessage.fromMap(jsonDecode(source) as Map<String, dynamic>);
}
