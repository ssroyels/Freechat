# Offline Group Chat (Bluetooth ke zariye, bina Internet)

Yeh ek Flutter app hai jisse aap **bina internet ke**, Bluetooth range me maujood
kai devices ke saath group chat kar sakte hain. Jab koi message bhejta hai, to
wo saare connected devices ko forward (relay) ho jaata hai — jaise ek chhota
"mesh" network.

## Kaam kaise karta hai

- Har device ek saath **advertise** (dusron ko dikhna) aur **discover**
  (dusron ko dhoondhna) karta hai — [`Strategy.P2P_CLUSTER`] use hota hai,
  jo one-to-one nahi balki **group (many-to-many)** connections banata hai.
- Jab koi message milta hai, wo turant screen par dikhta hai AUR baaki sab
  connected devices ko forward ho jaata hai (flooding), taaki range badhe.
- Har message ki unique ID hoti hai taaki wahi message baar-baar loop na ho.
- **Internet ki bilkul zaroorat nahi.** Underlying transport Google ka
  *Nearby Connections API* hai, jo Bluetooth (Classic + BLE) ko primary
  transport ki tarah use karta hai, aur behtar speed/range ke liye zaroorat
  padne par Wi-Fi Direct par switch ho sakta hai — dono hi offline hain,
  koi internet/mobile data nahi lagta.

## ⚠️ Zaroori sacchai (please padhein)

1. **Android** par yeh poori tarah kaam karega — `nearby_connections`
   package Android par bahut stable hai.
2. **iOS** par Apple ka Bluetooth model alag hai (peripheral/central roles
   ko lekar sakht restrictions). `nearby_connections` package ka iOS support
   limited/experimental hai. Agar aapko production-grade iOS app chahiye,
   to iOS side ke liye Apple ke **MultipeerConnectivity** framework par
   based ek native module likhna behtar hoga — main uska structure bhi
   bana sakta hoon agar chahiye.
3. Do devices connect tabhi honge jab dono me yeh app **khula (foreground
   ya kam se kam recently active) ho** — background me lambe samay tak
   chalna OS battery-saving restrictions ki wajah se guaranteed nahi hai.
4. Range: typically **10-100 meters**, obstacles (deewarein) se kam ho
   sakti hai.

## Setup kaise karein

1. [Flutter SDK install karein](https://docs.flutter.dev/get-started/install)
   agar pehle se nahi hai.
2. Terminal me project folder me jaake dependencies install karein:
   ```
   flutter pub get
   ```
3. Do (ya zyada) Android phones ko USB se connect karein ya emulator ready
   rakhein (BLE ke liye **real devices** chahiye, emulator me Bluetooth
   kaam nahi karta).
4. App run karein:
   ```
   flutter run
   ```
5. Har device par apna naam daalein aur "Group Chat Shuru Karein" dabayein.
   Bluetooth aur Location permissions allow karein.
6. Jaise hi doosra device range me aayega aur usme bhi app khula hoga,
   dono apne-aap connect ho jaayenge aur chat shuru ho jaayegi.

## Folder structure

```
lib/
  main.dart                  - App entry point
  models/chat_message.dart   - Message ka data structure
  services/
    mesh_chat_service.dart   - Poora Bluetooth/Nearby networking logic
    permission_helper.dart   - Runtime permissions maangna
  screens/
    home_screen.dart         - Naam enter karne wali screen
    chat_screen.dart         - Chat UI
  widgets/message_bubble.dart - Ek message ka UI
android/  - Android permissions (AndroidManifest.xml)
ios/      - iOS permissions (Info.plist)
```

## Aage badhane ke ideas

- Messages ko local database (e.g. `sqflite`) me save karna taaki app band
  hone par bhi history rahe.
- End-to-end encryption add karna taaki messages sirf sahi log padh sakein.
- File/photo sharing add karna.
- iOS ke liye MultipeerConnectivity based native implementation.
